# -*- coding: utf-8 -*-


#여기는 헤더와 바디의 structure 입니다~~~

class header_body():
    #ASC 파일의 헤더의 값을 여기에 담아요... 음... 나중에 저장할 때는 그냥 쓰는 걸로
    ncols=0
    nrows = 0
    xllcorner = 0
    yllcorner = 0
    cellsize = 0
    nodata_value = 0

    #그리고 ASC  파일의 몸통! 바디!!
    body = []